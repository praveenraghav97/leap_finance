import java.io.Serializable;
import org.json.simple.JSONObject;
import java.util.*;

// In this class we dont want to expose our data so we are not creating the setter Methods
public class KeyValue implements Serializable {
    private String key;
    private long timeToLive;
    private JSONObject value;
    private long creationTime;
    KeyValue(String key, long timeToLive, JSONObject value) {
        this.key = key;
        this.timeToLive = timeToLive;
        this.value = value;
        this.creationTime = (new Date().getTime());
    }
    public String getKey() {
        return key;
    }

    public long getTimeToLive() {
        return timeToLive;
    }

    public JSONObject getValue() {
        return value;
    }

    public long getCreationTime() {
        return creationTime;
    }
}