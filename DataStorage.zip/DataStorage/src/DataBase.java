import org.json.simple.JSONObject;
import java.util.concurrent.locks.ReentrantLock;
import java.io.*;
import java.lang.management.ManagementFactory;

public class DataBase {
    private String path;

    // Default Constrocture with path
    DataBase(String path) {

        this.path = path;
        File file = new File(path);

        if(!file.exists()) {
            file.mkdir();
        }

        this.path = this.path+"\\"+ManagementFactory.getRuntimeMXBean().getName();
    }

    // Default Constrocture without path
    DataBase() {

        this.path = System.getProperty("user.dir")+"\\AllFiles"; //Default path
        File file = new File(path);

        if(!file.exists()) {
            file.mkdir();
        }

        // Seperate Storage for reach Client
        this.path = this.path+"\\"+ManagementFactory.getRuntimeMXBean().getName();
    }


    // Creating Data without timeToLive time.
    public String create(String key, JSONObject jsonObject) {


        // We set timeToLive = -1 that will indicate that there is no timeToLive
        return create( key,  jsonObject, -1);
    }

    public String create(String key, JSONObject jsonObject, long timeToLive) {

        //Key constraint checking
        if(key == null || key.equals("") ||  key.length() > 32)
            return "Invalid Key : length of Key is more than 32";

        KeyValue value = new KeyValue(key,  timeToLive, jsonObject);

        // For Synchronization we are using the ReentrantLock that is best way ot Synchronization
        // without Busy waiting Problem
        ReentrantLock lock = new ReentrantLock();

        String result = null;

        if(lock.tryLock()) { // If lock is Free Acquire it.
            lock.lock();
            result = CRDOperation.create(value, path);
            lock.unlock();
        }
        return result;
    }

    public String delete(String key) {
        // For Synchronization we are using the ReentrantLock that is best way ot Synchronization
        // without Busy waiting Problem
        ReentrantLock lock = new ReentrantLock();
        String result = null;
        if(lock.tryLock()) { // If lock is Free Acquire it.
            lock.lock();
            result = result = CRDOperation.delete(key, path);
            lock.unlock();
        }
        return result;
    }

    public synchronized JSONObject read(String key) {
        // For Synchronization we are using the ReentrantLock that is best way ot Synchronization
        // without Busy waiting Problem
        ReentrantLock lock = new ReentrantLock();
        Object data = null;
        if(lock.tryLock()) { // If lock is Free Acquire it.
            lock.lock();
            data = CRDOperation.read(key, path);
            lock.unlock();
        }
        if(data instanceof KeyValue) {
            return ((KeyValue) data).getValue();
        }
        System.out.println(data);
        return null;
    }
}
