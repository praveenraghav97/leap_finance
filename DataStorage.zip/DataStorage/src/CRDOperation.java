import java.util.*;
import java.io.*;

public class CRDOperation {
    //Creating of new DataEntry
    public static String create(KeyValue data, String filePath) {
        FileOutputStream fileOutputStream = null;
        ObjectOutputStream objectOutputStream = null;
        FileInputStream fileInputStream = null;
        ObjectInputStream objectInputStream = null;
        HashMap<String, KeyValue> map = null;
        try {
            File file = new File(filePath);
            // check if files exists
            if (file.exists()) {
                fileInputStream = new FileInputStream(file);
                objectInputStream = new ObjectInputStream(fileInputStream);
                map = (HashMap<String, KeyValue>) objectInputStream .readObject();
                // reading all the Existing data and for processing store into HashMap
                fileInputStream.close();
                objectInputStream.close();
                // check if key already exists
                if(map.containsKey(data.getKey())) {
                    //If key present but timeToLive expires then remove that key(Entry) from database
                    //And updating the Original database
                    // update the dataset by rewriting the data
                    if (data.getTimeToLive() > 0 && (new Date().getTime() - (map.get(data.getKey()).getCreationTime()) >= (map.get(data.getKey()).getTimeToLive() * 1000))) {
                        map.remove(data.getKey());
                        map.put(data.getKey(), data);
                        fileOutputStream = new FileOutputStream(file);
                        objectOutputStream = new ObjectOutputStream(fileOutputStream);
                        objectOutputStream.writeObject(map);
                        fileOutputStream.close();
                        objectOutputStream.close();
                    } else {
                        return "Failure: key "+data.getKey()+" already preset";
                    }
                } else {
                    //Adding the New Key
                    map.put(data.getKey(), data);
                    fileOutputStream = new FileOutputStream(file);
                    objectOutputStream = new ObjectOutputStream(fileOutputStream);
                    objectOutputStream.writeObject(map);
                    fileOutputStream.close();
                    objectOutputStream.close();
                }

            } else {
                // If File does not exists creating Database and Inserting data
                map = new HashMap <String, KeyValue>();
                map.put(data.getKey(), data);
                fileOutputStream = new FileOutputStream(file);
                objectOutputStream = new ObjectOutputStream(fileOutputStream);
                objectOutputStream.writeObject(map);
                fileOutputStream.close();
                objectOutputStream.close();
            }
        } catch (Exception exception) {
            return "Failure : Input Output Exception Occurse";
        } finally {
            try {
                if (fileInputStream != null) {
                    fileInputStream.close();
                }
                if (objectInputStream != null) {
                    objectInputStream.close();
                }
                if (fileOutputStream != null) {
                    fileOutputStream.close();
                }
                if (objectOutputStream != null) {
                    objectOutputStream.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return "Sucess key "+data.getKey()+" added sucessfully";
    }

    public static String delete(String key, String path) {
        FileOutputStream fileOutputStream = null;
        ObjectOutputStream objectOutputStream = null;
        FileInputStream fileInputStream = null;
        ObjectInputStream objectInputStream = null;
        HashMap <String, KeyValue> map = null;
        File file = null;
        KeyValue data = null;
        String ans = "Success : key "+key+" Deleted";
        try {
            file = new File(path);
            //If file is not present not key found return nothing
            if(!file.exists())
                return "Failure: Current user does not contains any key";

            fileInputStream = new FileInputStream(file);
            objectInputStream = new ObjectInputStream(fileInputStream);
            map = (HashMap <String, KeyValue>) objectInputStream.readObject();
            // Reading Data
            data = map.get(key);
            //Get the value corresponding to the given key
            if(data != null) {
                //If key present but timeToLive expires then remove that key(Entry) from database
                // update the dataset by rewriting the data after deletion
                if (data.getTimeToLive() > 0 && (new Date().getTime() - (map.get(data.getKey()).getCreationTime()) >= (map.get(data.getKey()).getTimeToLive() * 1000))) {
                    ans = "Failure : Key "+key+" is not present";
                }
                map.remove(data.getKey());
                fileOutputStream = new FileOutputStream(file);
                objectOutputStream = new ObjectOutputStream(fileOutputStream);
                objectOutputStream.writeObject(map);
                fileOutputStream.close();
                objectOutputStream.close();
            } else {
                //if key not present
                ans = "Failure : Key "+key+" is not present";
            }
            // If key presnet remove it from datafile and update the file.
            map.remove(key);
            fileOutputStream = new FileOutputStream(file);
            objectOutputStream = new ObjectOutputStream(fileOutputStream);
            objectOutputStream.writeObject(map);
        } catch(Exception e) {
            return e.getMessage();
        } finally {
            try {
                map = null;
                fileInputStream.close();
                objectInputStream.close();
                fileOutputStream.close();
                objectOutputStream.close();
            } catch (Exception e) {

            }
        }
        return ans;
    }

    public static Object read(String key, String path) {
        FileInputStream fileInputStream = null;
        ObjectInputStream objectInputStream = null;
        HashMap <String, KeyValue> map = null;
        KeyValue data = null;
        try {

            File file = new File(path);
            if(!file.exists()) {
                //If file not found (Key Not found)
                return "Failure: Current user does not contains any key";
            }

            fileInputStream = new FileInputStream(file);
            objectInputStream = new ObjectInputStream(fileInputStream);
            map = (HashMap <String, KeyValue>) objectInputStream.readObject();
            data = map.get(key);
            if(data == null) {
                return "Failure: key "+key+" is not present";
            }
            //If key present but timeToLive expires then remove that key(Entry) from database
            // update the dataset by rewriting the data after deletion
            if ((data.getTimeToLive() > 0) && ((new Date().getTime()) > (data.getCreationTime() + data.getTimeToLive() * 1000))) {
                map.remove(data.getKey());
                return "Failure: Key Wrong Condition"+key+" is not present";
            }
            //Finally Data is correct and return the Data
            return data;
        } catch(Exception e) {
            return "Key is not Present";
        } finally {
            try {
                map = null;
                fileInputStream.close();
                objectInputStream.close();
            } catch (Exception e) {

            }
        }
    }
}
