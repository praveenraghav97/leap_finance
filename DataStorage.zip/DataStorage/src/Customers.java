import org.json.simple.JSONObject;

public class Customers {
    public static void main(String args[]) {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("key", "Value");
        DataBase database = new DataBase("C:\\Users\\dell\\Desktop\\Modern Reinforcement Learning- Deep Q Learning in PyTorch\\02 Fundamentals of Reinforcement Learning\\New folder");
        System.out.println(database.create("1", jsonObject, 40));// success
        System.out.println(database.read("1"));// success
        System.out.println(database.delete("1"));// success
    }
}
